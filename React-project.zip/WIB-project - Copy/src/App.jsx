
import './App.css'
import About from './Component/About';
import Blog from './Component/Blog';
import Contact from './Component/Contact';

import Home from './Component/Home';
import Layout from './Component/Layout';

import {
  createBrowserRouter,
  createRoutesFromElements,
  Route,
  RouterProvider,
} from "react-router";



function App() {
  const router = createBrowserRouter([
    {
      path:"/",
      element:<Layout />,
      children:[
        {path:"/",
          element:<Home />
        },
        {path:"/about",
          element:<About />
        },
        {path:"/blog",
          element:<Blog />
        },
        {path:"/contact",
          element:<Contact/>
        },
      ]
    }
  ])
  
  

  return (
    <>
     {/* <Crud /> */}
    {/* <Sec1 /> */}
    <RouterProvider router={router} />

    </>
  )
}

export default App
