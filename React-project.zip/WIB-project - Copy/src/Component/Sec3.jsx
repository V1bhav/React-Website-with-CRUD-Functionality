import { Container } from '@mui/material'
import React from 'react'
import chooseus from "../images/why-choose-us-img.jpg"
import truck from "../images/truck.svg"
import bag from "../images/bag.svg"
import support from "../images/support.svg"
import loop from "../images/return.svg"

function Sec3() {
  return (
    <>
      <Container maxWidth="lg">
        <div className="Sec3">
          <div className="sec31">
            <div className="subsec31">
              <h2 style={{ fontSize: 35, fontFamily: "sans-serif", fontWeight: 500, marginTop: 140 }}>Why Choose Us</h2>
              <h5 style={{ color: "grey", fontFamily: "sans-serif", fontWeight: 300 }}>Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique.</h5>
            </div>
            <div style={{ display: "flex" }}>
              <div className="subsec32">
                <div>
                  <img src={truck} alt="" />
                  <h4 style={{ margin: 0, paddingTop: 10,fontSize:14 ,fontFamily:"sans-serif" }}> Fast & Free Shipping </h4>
                  <p style={{ margin: 5, paddingBottom:50,color:"gray" }}>Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate  </p>
                </div>
                <div>
                  <img src={support} alt="" />
                  <h4 style={{ margin: 0, paddingTop: 10,fontSize:14,fontFamily:"sans-serif"  }}> Fast & Free Shipping </h4>
                  <p style={{ margin: 5, paddingBottom: 50 ,color:"gray" }}>Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate  </p>
                </div>

              </div>
              <div className="subsec33">
              <div>
                <img src={bag} alt="" />
                  <h4 style={{ margin: 0, paddingTop: 10 ,fontSize:14,fontFamily:"sans-serif" }}> Fast & Free Shipping </h4>
                  <p style={{ margin: 5, paddingBottom:50,color:"gray"  }}>Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate  </p>
                </div>
                <div>
                  <img src={loop} alt="" />
                  <h4 style={{ margin: 0, paddingTop: 10,fontSize:14,fontFamily:"sans-serif" }}> Fast & Free Shipping </h4>
                  <p style={{ margin: 5, paddingBottom: 50,color:"gray"  }}>Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="sec32">
              <img src={chooseus} style={{width:470,margin:25,paddingTop:160,borderRadius:40}} />
          </div>
        </div>
      </Container>
    </>
  )
}

export default Sec3