import { Card, CardContent, Typography } from '@mui/material';
import axios from 'axios';
import React, { useState, useEffect } from 'react';

function Blog() {
  const [user, setUser] = useState([]);

  const getData = async () => {
    try {
      const res = await axios.get('https://fakestoreapi.com/products');
      setUser(res.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <div style={{ display: "flex", flexWrap: 'wrap' }}>
      {user.map((x) => (
        <Card
          key={x.id}
          style={{
            width: '18rem',
            border: "1px solid black",
            margin: "10px",
            borderRadius: "25px",
            display: "flex"
          }}
        >
          <CardContent>
            <Typography variant="h6">{x.title}</Typography>
            <Typography variant="body2">{x.description.substring(0)}</Typography>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export default Blog;
