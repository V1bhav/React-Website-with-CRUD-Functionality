import { Avatar, Container } from '@mui/material'
import React from 'react'
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from 'react-slick';
import testimonial1 from "../images/person_1.jpg"
import testimonial2 from "../images/person_2.jpg"
import testimonial3 from "../images/person_3.jpg"
import testimonial4 from "../images/person_4.jpg"

function Sec5() {
  const settings = {
   
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    speed: 2000,
    autoplaySpeed: 800,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };
  return (
    <>
      <div className="Sec5">
        <Container maxWidth="lg">
          <div className="slider-container">
            <Slider {...settings}>
              <div className='slide'>
                <h1 style={{ color: "black" }}>Corey Gibbs</h1>
                <div>
                  <h4>“Donec facilisis quam ut purus rutrum lobortis. Donec vitae odio quis nisl dapibus malesuada.<br></br> Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique.<br></br>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.”</h4>
                  <div className='avatar-wrapper'>
                    <Avatar sx={{ display: 'flex', gap: 2 }} src={testimonial1} size="lg" />
                  </div>
                </div>
              </div>
              <div className='slide'>
                <h1 style={{ color: "black" }}>Nathan Lawson</h1>
                <div>
                  <h4>“Donec facilisis quam ut purus rutrum lobortis. Donec vitae odio quis nisl dapibus malesuada.<br></br> Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique.<br></br>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.”</h4>
                  <div className='avatar-wrapper'>
                    <Avatar sx={{ display: 'flex', gap: 2 }} src={testimonial2} size="lg" />
                  </div>
                </div>
              </div>
              <div className='slide'>
                <h1 style={{ color: "black" }}>Rhys O’Neal</h1>
                <div>
                  <h4>“Donec facilisis quam ut purus rutrum lobortis. Donec vitae odio quis nisl dapibus malesuada.<br></br> Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique.<br></br>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.”</h4>
                  <div className='avatar-wrapper'>
                    <Avatar sx={{ display: 'flex', gap: 2 }} src={testimonial3} size="lg" />
                  </div>
                </div>
              </div>
              <div className='slide'>
                <h1 style={{ color: "black" }}>Walter Barr</h1>
                <div>
                  <h4>“Donec facilisis quam ut purus rutrum lobortis. Donec vitae odio quis nisl dapibus malesuada.<br></br> Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique.<br></br>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas..”</h4>
                  <div className='avatar-wrapper'>
                    <Avatar sx={{ display: 'flex', gap: 2 }} src={testimonial4} size="lg" />
                  </div>
                </div>
              </div>
              <div className='slide'>
                <h1 style={{ color: "black" }}>Kingsley McCann</h1>
                <div>
                  <h4>“Donec facilisis quam ut purus rutrum lobortis. Donec vitae odio quis nisl dapibus malesuada.<br></br> Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique.<br></br>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.”</h4>
                  <div className='avatar-wrapper'>
                    <Avatar sx={{ display: 'flex', gap: 2 }} src={testimonial2} size="lg" />
                  </div>
                </div>
              </div>
              <div className='slide'>
                <h1 style={{ color: "black" }}>Lauren Burns</h1>
                <div>
                  <h4>“Donec facilisis quam ut purus rutrum lobortis. Donec vitae odio quis nisl dapibus malesuada.<br></br> Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique.<br></br>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.”</h4>
                  <div className='avatar-wrapper'>
                    <Avatar sx={{ display: 'flex', gap: 2 }} src={testimonial3} size="lg" />
                  </div>
                </div>
              </div>
              <div className='slide'>
                <h1 style={{ color: "black" }}>Lauren Burns</h1>
                <div>
                  <h4>“Donec facilisis quam ut purus rutrum lobortis. Donec vitae odio quis nisl dapibus malesuada.<br></br> Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique.<br></br>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. ”</h4>
                  <div className='avatar-wrapper'>
                    <Avatar sx={{ display: 'flex', gap: 2 }} src={testimonial3} size="lg" />
                  </div>
                </div>
              </div>

            </Slider>
          </div>
        </Container>
      </div>
    </>
  )
}

export default Sec5