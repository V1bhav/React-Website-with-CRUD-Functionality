import { Container } from '@mui/material'
import React from 'react'
import img1 from "../images/img-grid-2.jpg"
import img2 from "../images/img-grid-3.jpg"

function Sec4() {
  return (
    <>
      <Container maxWidth="lg">
        <div className="Sec4">
          <div className="subsec41">
          <img src={img2} alt="" style={{paddingLeft:80,paddingTop:10,width:700,borderRadius:40}} />
          </div>
          <div className="subsec42">
            <h2 style={{ fontSize: 35, fontFamily: "sans-serif", fontWeight: 500, marginTop: 140 }}>We Help You Make Modern Interior Design</h2>
            <p style={{ margin: 5, paddingBottom: 50, color: "gray" }}>Donec facilisis quam ut purus rutrum lobortis. Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique. Pellentesque habitant morbi tristique senectus et netus et malesuada </p>
            <img src={img1} alt="" />

        
          </div>
        </div>
      </Container>
    </>
  )
}

export default Sec4