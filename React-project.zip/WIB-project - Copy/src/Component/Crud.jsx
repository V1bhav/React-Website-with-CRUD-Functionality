import React, { useState } from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import CardActionArea from '@mui/material/CardActionArea';
import CardActions from '@mui/material/CardActions';
import { useForm } from "react-hook-form";
import { Container, Input } from '@mui/material';
import { Snackbar, Alert } from '@mui/material';



function Crud() {
  const [user, setuser] = useState([]);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm();

  const toBase64 = file =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
    });

  async function add(data) {

    const file = data.profile[0];
    data.image = await toBase64(file);
    console.log(data);

    setuser(previous => {
      let updated = [...previous]
      const userexist = updated.findIndex(x => x.id == data.id);

      if (userexist !== -1) {
        data.id = parseInt(data.id);
        updated[userexist] = { ...data };
        setSnackbarMessage('User updated successfully');
      }
      else {
        const newuser = previous.length > 0 ? previous[previous.length - 1].id + 1 : 1;
        data.id = newuser;
        updated.push(data);
        setSnackbarMessage('User added successfully');
      }

      localStorage.setItem("userdata", JSON.stringify(updated));
      return updated;
    });


    setSnackbarOpen(true);

    reset();
  }


  const edit = (id) => {
    const editData = user.find(x => x.id === id);
    for (const key in editData) {
      setValue(key, editData[key]);
    }
  };


  const deleteObj = (id) => {
    if (window.confirm("Are You Sure?")) {
      setuser(preuser => {
        const updateduser = preuser.filter(x => x.id !== id);
        localStorage.setItem("userdata", JSON.stringify(updateduser));
        return updateduser;
      });
    }
  };



  return (
    <>
      <Container>
        <form className='form1' onSubmit={handleSubmit(add)}>
          <Input
            type="hidden"
            {...register("id")}
          />
          <Input
            type="text"
            placeholder="First Name"
            {...register("firstName", { required: true, maxLength: 20 })}
          />
          {errors.firstName && <p style={{ color: "red", fontSize: "10px" }}>First name is required</p>}
          <br />

          <Input
            type="email"
            placeholder="Email"
            {...register("email", {
              required: "Email is required",
              pattern: {
                value: /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/,
                message: "Invalid email address"
              }
            })} />
          {errors.email && <p style={{ color: "red", fontSize: "10px" }}>{errors.email.message}</p>}
          <br />

          <Input
            type="text"
            placeholder="City"
            {...register("city", { required: true })} />
          {errors.city && (<p style={{ color: "red", fontSize: "10px" }}> City is required</p>)}
          <br />

          <Input
            type="tel"
            placeholder="Mobile Number"
            {...register("mobile", {
              required: true,
              pattern: /^[0-9]{10}$/
            })} />
          {errors.mobile && (<p style={{ color: "red", fontSize: "10px" }}> Please enter a valid 10-digit mobile number</p>)}
          <br />

          <Input
            type="password"
            placeholder="Password"
            {...register("password", {
              required: "Password is required",
              minLength: {
                value: 8,
                message: "Password must be at least 8 characters long"
              }
            })}
          />
          {errors.password && <p style={{ color: "red", fontSize: "10px" }}>{errors.password.message}</p>}
          <br />

          <Input
            type="file"
            accept=".jpg,.jpeg"
            {...register("profile", {
              required: "Profile image is required",
              validate: {
                isJpg: (fileList) =>
                  fileList[0]?.type === "image/jpeg" || "Only JPG files are allowed"
              }
            })}
          />
          {errors.profile && <p style={{ color: "red", fontSize: "10px" }}>{errors.profile.message}</p>}
          <br />

          <Button variant="outlined" type="submit">Submit</Button>
        </form>
      </Container>

      <hr />

      <div className='cardbox'>
        {user.map((x) => (
          <Card sx={{ maxWidth: 345, margin: 2, padding: 5, borderRadius: 15 }} key={x.id}>
            <CardActionArea>
              <CardMedia
                component="img"
                height="140"
                image={x.image}
                alt="User Profile"
                style={{ borderRadius: 15 }}
              />
              <CardContent >
                <Typography gutterBottom variant="h5" component="div">
                  Name: {x.firstName}
                </Typography>
                <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                  Email: {x.email}
                  <br></br>
                  City: {x.city}
                  <br></br>
                  Password: {x.password}
                  <br></br>
                  Contact: {x.mobile}
                </Typography>
              </CardContent>
            </CardActionArea>
            <CardActions>
              <Button size="small" variant="outlined" color="info" onClick={() => edit(x.id)}>
                Update
              </Button>
              <Button size="small" variant="outlined" color="warning" onClick={() => deleteObj(x.id)}>
                Delete
              </Button>
            </CardActions>
          </Card>
        ))}
          <Snackbar
          open={snackbarOpen}
          autoHideDuration={3000}
          onClose={() => setSnackbarOpen(false)}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        >
          <Alert onClose={() => setSnackbarOpen(false)} severity="success" sx={{ width: '100%' }}>
            {snackbarMessage}
          </Alert>
        </Snackbar>
      </div>
      
    </>
  );
}

export default Crud;
