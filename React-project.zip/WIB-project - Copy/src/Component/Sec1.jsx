import React from 'react'
import Header from './Header'
import { Container } from '@mui/material'
import sofa from "../images/couch.png"

function Sec1() {
  return (
    <>
        <div className="sec1">
        <Container maxWidth="lg" >
            <div className="subsec1">
                <div className="sub1">
                 

                  <h1>Modern Interior </h1>
                  <span style={{fontSize:30}}>Design Studio</span>
                 
                </div>
                <div className="sub2">
                  <img src={sofa} alt=""  className="sofa"/>
                </div>
            </div>
        </Container>
        </div>
    </>
  )
}

export default Sec1