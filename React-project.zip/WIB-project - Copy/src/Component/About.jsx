import React from 'react'
import Crud from './Crud'


function About() {
  return (
    <h1>
       <Crud />
    </h1>
  )
}

export default About