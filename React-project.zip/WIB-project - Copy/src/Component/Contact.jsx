import { Container } from '@mui/material'
import React from 'react'

function Contact() {
  return (
    <>
      <Container>
        <div style={{textAlign:"center",backgroundColor:"#81c784", borderRadius:10,padding:10,margin:10}}>
          <h1 style={{color:'white'}}>ABOUT US</h1>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima dolorem quasi voluptate possimus dolore, fugit numquam aliquam? Adipisci illo molestias nihil nisi dolores eligendi dolore, quo, vitae ea pariatur natus voluptas nemo fuga mollitia. Fugiat saepe fuga doloribus maiores. Accusamus ipsa cumque corporis dignissimos laudantium repudiandae enim, aliquid nobis dicta?</p>
        </div>
      </Container>
    </>
  )
}

export default Contact