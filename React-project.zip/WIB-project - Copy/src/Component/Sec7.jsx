import { Container } from '@mui/material'
import React from 'react'
import { Box, Grid, Typography, TextField, Button, Divider, Link } from '@mui/material';
// import TwitterIcon from '@mui/icons-material/Twitter';
// import FacebookIcon from '@mui/icons-material/Facebook';
// import InstagramIcon from '@mui/icons-material/Instagram';


function Sec7() {
  return (
    <>
     <div className="Sec7">
     <Box component="footer" sx={{ bgcolor: 'background.paper', py: 6 }}>
      <Container maxWidth="lg">
        {/* Newsletter Section */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h5" gutterBottom>
            Subscribe to Newsletter
          </Typography>
          <Box component="form" sx={{ display: 'flex', gap: 2, mb: 3 ,width:300}}>
           
            <TextField
              label="Enter your email"
              variant="outlined"
              size="small"
              fullWidth
            />
          </Box>
          <Button variant="contained" color="primary">
            Subscribe
          </Button>
        </Box>

        <Divider sx={{ my: 4 }} />

        {/* Brand and Description */}
        <Typography variant="h6" gutterBottom>
          <h1>Furni.io</h1>
        </Typography>
        <Typography variant="body2" color="text.secondary" paragraph sx={{ mb: 4, maxWidth: '500px' }}>
          Donec facilisis quam ut purus rutrum lobortis. Donec vitae odio quis nisi dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique. Pellentesque habitant
        </Typography>

        {/* Links Grid */}
        <Grid container spacing={4}>
          <Grid item xs={6} sm={3}>
            <Typography variant="subtitle1" gutterBottom>
              About us
            </Typography>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>Services</Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>Blog</Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>Contact us</Link>
          </Grid>

          <Grid item xs={6} sm={3}>
            <Typography variant="subtitle1" gutterBottom>
              Support
            </Typography>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>Knowledge base</Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>Live chat</Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>Privacy Policy</Link>
          </Grid>

          <Grid item xs={6} sm={3}>
            <Typography variant="subtitle1" gutterBottom>
              Jobs
            </Typography>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>Our team</Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>Leadership</Link>
          </Grid>

          <Grid item xs={6} sm={3}>
            <Typography variant="subtitle1" gutterBottom>
              Products
            </Typography>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>Nordic Chair</Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>Kruzo Aero</Link>
            <Link href="#" variant="body2" color="text.secondary" display="block" gutterBottom>Ergonomic Chair</Link>
          </Grid>
        </Grid>
      </Container>
    </Box>
        </div>
    </>
  )
}

export default Sec7