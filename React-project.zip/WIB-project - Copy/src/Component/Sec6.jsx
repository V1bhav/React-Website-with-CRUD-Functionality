import { Box, Container, Typography } from '@mui/material'
import React from 'react'
import sofa1 from "../images/sofa.png"


function Sec6() {
  return (
    <>
      <Container>
        <Box sx={{ mt: { xs: 6, md: 12 }, display: 'flex', flexDirection: { xs: 'column', md: 'row' }, alignItems: 'center', justifyContent: 'center', }}>
          <Box sx={{ width: { xs: '100%', md: '50%' }, px: 2, textAlign: { xs: 'center', md: 'left' }, }}>
            <Typography sx={{ color: 'gray', fontFamily: 'sans-serif', fontSize: { xs: '16px', sm: '18px', md: '20px' }, }}>
             Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quo qui, aut dicta non soluta voluptatibus, earum culpa deserunt deleniti possimus laudantium assumenda nesciunt repellat molestiae?
            </Typography>
            <Typography sx={{ color: 'gray', fontFamily: 'sans-serif', fontSize: { xs: '16px', sm: '18px', md: '20px' }, }}>
             Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quo qui, aut dicta non soluta voluptatibus, earum culpa deserunt deleniti possimus laudantium assumenda nesciunt repellat molestiae?
            </Typography>
            <Typography sx={{ color: 'gray', fontFamily: 'sans-serif', fontSize: { xs: '16px', sm: '18px', md: '20px' }, }}>
             Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quo qui, aut dicta non soluta voluptatibus, earum culpa deserunt deleniti possimus laudantium assumenda nesciunt repellat molestiae?
            </Typography>
          </Box>

          <Box sx={{width: { xs: '100%', md: '50%' },display: 'flex',justifyContent: 'center', mt: { xs: 4, md: 0 },}}>
            <Box component="img" src={sofa1}
             sx={{
                height: { xs: 200, sm: 250, md: 300 },
                maxWidth: '100%',
                ml: { xs: 0, md: 10 },
                mt: { xs: 2, md: 10 },
              }}
            />
          </Box>
        </Box>
      </Container>
    </>
  )
}

export default Sec6