import { Container } from '@mui/material'
import React from 'react'
import product1 from "../images/product-1.png"
import product2 from "../images/product-2.png"
import product3 from "../images/product-3.png"

function Sec2() {
  return (
    <>
      <Container  maxWidth="lg">
        <div className="Sec2">
            
                <div className="sec21">
                  <div style={{marginTop:100}}>
                    <p style={{fontSize:35,fontFamily:"sans-serif",fontWeight:500}}>Crafted with excellent material.</p>
                    <p style={{fontSize:15,fontFamily:"sans-serif",color:"gray"}}>Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique.</p>
                  </div>
                </div>
                <div className="sec21">
                  <img src={product1} alt="" />
                </div>
                <div className="sec21">
                <img src={product2} alt="" />
                </div>
                <div className="sec21">
                <img src={product3} alt="" />
                </div>
        </div>
            </Container>
    </>
  )
}

export default Sec2