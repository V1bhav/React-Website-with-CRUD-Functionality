import { Grid } from '@mui/material'
import React from 'react'
import { NavLink } from 'react-router-dom'

function Header() {
    return (
        <>
        <div className="megaheader">
            <div className="header ">
                <div className="s1"></div>
                <div className="s2">
                    <Grid container spacing={3}>
                        <Grid size="grow" >
                            <NavLink to ="/"className={({ isActive }) => (isActive ? 'active-link' : 'inactive-link')}
                            >Home</NavLink>
                        </Grid>
                        <Grid size="grow">
                        <NavLink to ="/contact" className={({ isActive }) => (isActive ? 'active-link' : 'inactive-link')}>About</NavLink>
                        </Grid>
                        <Grid size="grow">
                        <NavLink to ="/about" className={({ isActive }) => (isActive ? 'active-link' : 'inactive-link')}>Contact</NavLink>
                        </Grid>
                        <Grid size="grow">
                        <NavLink to ="/blog" className={({ isActive }) => (isActive ? 'active-link' : 'inactive-link')}>Blog</NavLink>
                        </Grid>
                       
                    </Grid>
                </div>
            </div>
            </div>
        </>
    )
}

export default Header